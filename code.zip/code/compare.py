import pandas as pd
from IPython.display import display

j1_large_df = pd.read_csv("../results/ai21_j1-large.csv")[["_id", "ref_answer", "answer"]].rename(
    columns={'answer': 'answer_j1_large'})
gpt3_df = pd.read_csv("../results/openaichat_gpt-3.5-turbo.csv")[["_id", "ref_answer", "answer"]].rename(
    columns={'answer': 'answer_gpt3'})
gpt4_df = pd.read_csv("../results/openaichat_gpt-4.csv")[["_id", "ref_answer", "answer"]].rename(
    columns={'answer': 'answer_gpt4'})
gptj_df = pd.read_csv("../results/textsynth_gptj_6B.csv")[["_id", "ref_answer", "answer"]].rename(
    columns={'answer': 'answer_gptj'})

j1_large_df['answer_j1_large'] = j1_large_df['answer_j1_large'].str.strip()
gpt3_df['answer_gpt3'] = gpt3_df['answer_gpt3'].str.strip()
gpt4_df['answer_gpt4'] = gpt4_df['answer_gpt4'].str.strip()
gptj_df['answer_gptj'] = gptj_df['answer_gptj'].str.strip()

j1_large_df["match_j1_large"] = j1_large_df["ref_answer"].str.strip() == j1_large_df["answer_j1_large"]
gpt3_df["match_gpt3"] = gpt3_df["ref_answer"].str.strip() == gpt3_df["answer_gpt3"]
gpt4_df["match_gpt4"] = gpt4_df["ref_answer"].str.strip() == gpt4_df["answer_gpt4"]
gptj_df["match_gptj"] = gptj_df["ref_answer"].str.strip() == gptj_df["answer_gptj"]

j1_large_df.drop('ref_answer', axis=1, inplace=True)
gpt3_df.drop('ref_answer', axis=1, inplace=True)
gpt4_df.drop('ref_answer', axis=1, inplace=True)
gptj_df.drop('ref_answer', axis=1, inplace=True)

results_df = pd.read_csv("../results.csv")

merged_df_1 = pd.merge(j1_large_df, gpt3_df, on='_id')
merged_df_2 = pd.merge(gpt4_df, gptj_df, on='_id')
merged_df = pd.merge(merged_df_1, merged_df_2, on='_id')

new_order = ["_id", "answer_j1_large", "answer_gpt3", "answer_gpt4", "answer_gptj",
             "match_j1_large", "match_gpt3", "match_gpt4", "match_gptj"]
merged_df = merged_df[new_order]

merged_df = pd.merge(merged_df, results_df, on='_id')

merged_df.drop('GPT4_answer', axis=1, inplace=True)

merged_df['ref_answer'] = merged_df['ref_answer'].str.strip()
merged_df['llm_cascade_answer'] = merged_df['llm_cascade_answer'].str.strip()
merged_df["correct"] = merged_df["llm_cascade_answer"] == merged_df["ref_answer"]
display(merged_df)

has_match = (merged_df['match_j1_large']) | \
            (merged_df['match_gpt3']) | \
            (merged_df['match_gpt4']) | \
            (merged_df['match_gptj'])

matched_df = merged_df[has_match]

matched_order = ["_id", "answer_j1_large", "answer_gpt3", "answer_gpt4", "answer_gptj", "llm_cascade_answer",
                 "ref_answer", "match_j1_large", "match_gpt3", "match_gpt4", "match_gptj", "answered_service_name",
                 "llm_cascade_cost", "GPT4_cost", "score", "correct"]

matched_df = matched_df[matched_order]
display(matched_df)
matched_df.to_csv("../matched.csv")
